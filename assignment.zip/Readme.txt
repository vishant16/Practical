
Tool
	DjangoFramework
	DjangoRestFramework


fuctionality

	1. Notification of particular user- data will display according to invitations.json file
		url-http://127.0.0.1:8000/api/user/1/
		
		1.1 After 2 second- page reloaded and give you updated notification with the help of inivitations_update.json file
			
		
	
	2. All notifications of all users
		http://127.0.0.1:8000/api/user/

