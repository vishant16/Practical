from django.shortcuts import render

from django.views.decorators.cache import cache_page
# Create your views here.
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.db.models import Q
from .serializers import DataSerializer
from .models import Data
import json
from django.http import Http404
from rest_framework.renderers import TemplateHTMLRenderer,JSONRenderer

i=[]
class UserList(APIView):
    renderer_classes = [TemplateHTMLRenderer]
    template_name = 'users.html'
    def get(self, request):
        Data.objects.all().delete()
        insertdata()
        articles = Data.objects.all()
  
        #serializer = DataSerializer(articles, many=True)
        return Response({'profiles': articles})
        #return Response(serializer.data)

    def post(self, request, format=None):
        serializer = DataSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class UserDetail(APIView):
    renderer_classes = [TemplateHTMLRenderer]
    template_name = 'profile.html'
    
    
    def get(self, request, pk, format=None):
        Data.objects.all().delete()
        insertdata()
        print(i)
       
        if len(i)==0:
            Data.objects.all().delete()
            insertdata()
            print("get",i)
            i.append(1)
            c= Data.objects.filter(user_id = pk).count()
            u=pk
            snippet= Data.objects.filter(user_id = pk)
            serializer = DataSerializer(snippet,many=True)
            
            return Response({'profiles': snippet,'count':c,'u':u})
        
        else:
            Data.objects.all().delete()
            update()
            print("update",i)
            c= Data.objects.filter(user_id = pk).count()
            u=pk
            snippet= Data.objects.filter(user_id = pk)
            serializer = DataSerializer(snippet,many=True)
            i.pop()
            return Response({'profiles': snippet,'count':c,'u':u})
       

        #return Response(serializer.data)
      
        #schedule.every(10).seconds.do(self.update)
     
    """
    def delete(self, request, pk, format=None):
        snippet = self.get_object(pk)
        snippet.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    def put(self, request, pk, format=None):
        snippet = self.get_object(pk)
        serializer = DataSerializer  (snippet, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)"""


def insertdata():
    #Data.objects.all().delete()
    f = open('static_data/invitations.json',)
    data = json.load(f)
    for i in data['invites']:
        invite_id=i['invite_id']
        sender_id=i['sender_id']
        sig_id=i['sig_id']
        invite=i['invite']
        vector=i['vector']
        invite_time=i['invite_time']
        user_id=i['user_id']
        status=i['status']
        
        p = Data(invite_id=invite_id, sender_id=sender_id,sig_id=sig_id,invite=invite
        ,vector=vector,invite_time=invite_time,user_id=user_id,status=status)
        p.save()

    f.close()


def update():
        #Data.objects.all().delete()
        f = open('static_data/invitations_update.json',)
        data = json.load(f)
        for i in data['invites']:
            invite_id=i['invite_id']
            sender_id=i['sender_id']
            sig_id=i['sig_id']
            invite=i['invite']
            vector=i['vector']
            invite_time=i['invite_time']
            user_id=i['user_id']
            status=i['status']
            
            p = Data(invite_id=invite_id, sender_id=sender_id,sig_id=sig_id,invite=invite
            ,vector=vector,invite_time=invite_time,user_id=user_id,status=status)
            p.save()

        f.close()
       