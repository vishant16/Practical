from django.db import models

# Create your models here.
class Data(models.Model):
    invite_id = models.IntegerField()
    sender_id = models.CharField(max_length=120)
    sig_id = models.CharField(max_length=120)
    invite = models.CharField(max_length=120)
    vector = models.CharField(max_length=120)
    invite_time = models.IntegerField()
    user_id = models.IntegerField()
    status = models.CharField(max_length=120)


    def __str__(self):
        return str(self.user_id)
