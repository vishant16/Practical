from rest_framework import serializers
from .models import Data


class DataSerializer(serializers.ModelSerializer):
    class Meta:
        model = Data
        fields = ('invite_id','sender_id','sig_id','invite','vector','invite_time','user_id','status')
